# CRUD-APP
Simple php crud app for beginners
